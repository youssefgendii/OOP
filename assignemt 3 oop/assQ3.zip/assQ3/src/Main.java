import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> arr=new ArrayList<Integer>();
        arr.add(1);
        arr.add(5);
        arr.add(4);
        arr.add(2);
        arr.add(3);
        sort(arr);
    }

    public static void sort(ArrayList<Integer> list){

        int temp = 0;

        for (int i = 0; i < list.size() - 1; i++) {
            for (int j = i+1; j < list.size(); j++) {
                if (list.get(j) < list.get(i)) {
                    temp = list.get(i);
                    list.set(i, list.get(j));
                    list.set(j, temp);
                }
            }
        }
        System.out.println(list);

    }
}